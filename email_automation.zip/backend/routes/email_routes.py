from fastapi import APIRouter
from services.imap_sync import get_emails

router = APIRouter()

@router.get("/")
def fetch_emails():
    """
    Fetches the last 30 days of emails from IMAP accounts.
    """
    emails = get_emails()
    return {"emails": emails}
