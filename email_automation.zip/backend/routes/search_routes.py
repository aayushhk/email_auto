from fastapi import APIRouter, Query
from elasticsearch import Elasticsearch

# Initialize Elasticsearch
es = Elasticsearch("http://localhost:9200")

# Create API Router
router = APIRouter()

@router.get("/search/")
def search_emails(query: str, folder: str = None, account: str = None):
    """
    Search emails in Elasticsearch by query.
    Supports filtering by folder and account.
    """
    search_body = {
        "query": {
            "bool": {
                "must": [{"match": {"content": query}}],
                "filter": []
            }
        }
    }

    if folder:
        search_body["query"]["bool"]["filter"].append({"term": {"folder": folder}})
    if account:
        search_body["query"]["bool"]["filter"].append({"term": {"account": account}})

    results = es.search(index="emails", body=search_body)

    return {"emails": [hit["_source"] for hit in results["hits"]["hits"]]}

