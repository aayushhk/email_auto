import faiss
import numpy as np
from sentence_transformers import SentenceTransformer

# Load sentence transformer model for embedding generation
model = SentenceTransformer("all-MiniLM-L6-v2")

# Vector database configuration
D = 384  # Dimension of embedding (depends on the model)
index = faiss.IndexFlatL2(D)  # L2 distance-based FAISS index

# Store email metadata (ID mapping)
email_metadata = {}

def add_to_vector_db(email_id, text):
    """Generate embeddings and store them in FAISS."""
    embedding = model.encode([text])[0]  # Convert text to embedding
    index.add(np.array([embedding]).astype("float32"))  # Add to FAISS
    email_metadata[index.ntotal - 1] = email_id  # Store ID mapping

def search_similar_emails(query, top_k=3):
    """Search for similar emails based on vector similarity."""
    query_embedding = model.encode([query])[0]
    _, indices = index.search(np.array([query_embedding]).astype("float32"), top_k)
    
    # Get matching email IDs
    results = [email_metadata[idx] for idx in indices[0] if idx in email_metadata]
    return results

if __name__ == "__main__":
    print("FAISS Vector DB initialized.")
